package edu.kit.informatik;
/**
  The {@code Interactiveface} class uses the BinarySearchTree,
   to create an interactive inerface.
   @author Ahmad.
   @version 1.0.
 */
public class Interactiveface {
    /**
     * @param args argument of the main method.
     */
public static void main(String []args) {
        Preorder<String, Integer> preorder = new Preorder<String, Integer>();
        Inorder<String, Integer> inorder = new Inorder<String, Integer>();
        Levelorder<String, Integer> levelorder
            = new Levelorder<String, Integer>();
        BinarySearchTree<String, Integer> city
        = new BinarySearchTree<String, Integer>();
        String firstWord = "";
        while (!firstWord.equals("quit")) {
            Terminal.printLine("Ented desired command");
            String command = Terminal.readLine();
            String[] spaceSplit = command.split(" ");
            firstWord = spaceSplit[0];
            if (firstWord.equals("insert")) {
                String[] dotsplitter = spaceSplit[1].split(":");
                String secondword = dotsplitter[0];
                int data = Integer.parseInt(secondword);
                String value = dotsplitter[1];
                city.insert(value, data);
            } else if (firstWord.equals("search")) {
                String[] dotsplitter = spaceSplit[1].split(":");
                String secondword = dotsplitter[0];
                int data = Integer.parseInt(secondword);
                Terminal.printLine(city.search(data));
            } else if (firstWord.equals("info")) {
                if (args.length == 0
                    || args[0].equals("traverse=inorder")) {
                    Terminal.printLine(
                    inorder.chosenTraversetype(city.getRoot(), ""));
                } else if (args[0].equals("traverse=preorder")) {
                    Terminal.printLine(
                    preorder.chosenTraversetype(city.getRoot(), ""));
                } else if (args[0].equals("traverse=levelorder")) {
                    Terminal.printLine(levelorder.chosenTraversetype(
                    city.getRoot(), ""));
                } else {
                     if (!args[1].equals("traverse=preorder")
                     && !args[1].equals("traverse=inorder")
                     && !args[1].equals("taverse=levelorder")) {
                     Terminal.printLine(
                     "Incomprehensive argument input");
                    }
                }
            }
        }
    }
}
